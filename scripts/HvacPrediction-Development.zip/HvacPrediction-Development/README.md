# HvacPrediction
HVAC Prediction model. 
Aims to predict system behavior using machine learning.

The system is built initially on YR for weather data and will calculate solar angles hourly for each day to have knowledge about the sun and sunlight.
Machine learning algorithms and models are made and running in Python. With the system running on a RPi5 8GB for controlling the HVAC and other necessarry onprem systems.

